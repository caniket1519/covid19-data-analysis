# COVID-19 Exploratory Data Analysis

A data analytics project that explores COVID-19 trends using Pandas, NumPy, and Seaborn. 
Visualizes case growth, recovery rates, and regional correlations.

## Libraries Used
- Pandas
- NumPy
- Matplotlib
- Seaborn
